package ui.automation.selenium.design.pattern.factory;

import org.openqa.selenium.WebDriver;

public interface Browser {
	
	WebDriver getBrowser();

}
