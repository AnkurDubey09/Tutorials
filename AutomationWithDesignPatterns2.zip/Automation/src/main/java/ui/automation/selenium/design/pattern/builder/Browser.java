package ui.automation.selenium.design.pattern.builder;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class Browser {
	
	private WebDriver browserInstance;
	
	
	public Browser() {
		
	}
	
		
	public static class OpenBrowser{
		private WebDriver browserInstance;
				
		public OpenBrowser(String browserName) {
			if(browserName.equalsIgnoreCase("CHROME")) {
				System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"/browser_exe/chromedriver.exe");
				this.browserInstance = new ChromeDriver();
			}
		}
		
		public OpenBrowser withUrl(String url) {
			this.browserInstance.get(url);
			return this;
		}
		
		public OpenBrowser withImplicitTimeoutInSecond(long timeOutInSecond) {
			this.browserInstance.manage().timeouts().implicitlyWait(timeOutInSecond, TimeUnit.SECONDS);
			return this;
		}
		
		public OpenBrowser maximizeBrowser() {
			this.browserInstance.manage().window().maximize();
			return this;
		}
		
		
		
		public Browser build(){
            
			Browser browser = new Browser(); 
            browser.browserInstance = this.browserInstance;
            
            return browser;
            
        }	
		
	}
	
	public WebDriver getBrowserHandle() {
		return this.browserInstance;
	}

}
