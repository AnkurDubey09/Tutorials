package ui.automation.selenium.design.pattern.factory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class FirefoxBrowser implements Browser{
	private static final String FF_DRIVER_PROPERTY = "webdriver.gecko.driver";
	public WebDriver getBrowser() {
		
		System.out.println("inside @FirefoxBrowser");
		System.setProperty(FF_DRIVER_PROPERTY, System.getProperty("user.dir")+"/browser_exe/gecko/geckodriver.exe");
		return new FirefoxDriver();
		
	}

}
