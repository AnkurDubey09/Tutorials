package ui.automation.selenium.design.pattern.builder;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

public class BuilderPatternDemo extends TestSoul{
	
	public static void main(String[] args) {
		
		WebDriver bro = getBrowserInstance();
		System.out.println(bro.getTitle());
		
		System.out.println(getUrl());
		
		bro.findElement(By.name("q")).sendKeys("Builder Design Pattern");
		bro.findElement(By.name("btnK")).sendKeys(Keys.ENTER);
		
	}

}
