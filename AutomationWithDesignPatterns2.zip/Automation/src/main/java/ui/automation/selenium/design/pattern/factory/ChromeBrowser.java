package ui.automation.selenium.design.pattern.factory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ChromeBrowser implements Browser {
	private static final String CHROME_DRIVER_PROPERTY = "webdriver.chrome.driver";
	
	public WebDriver getBrowser() {
		
		System.out.println("inside @ChromeBrowser");
		
		System.setProperty(CHROME_DRIVER_PROPERTY, System.getProperty("user.dir")+"/browser_exe/chromedriver.exe");
		return new ChromeDriver();
		
	}
	
	

}
