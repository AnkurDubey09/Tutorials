package ui.automation.selenium.design.pattern.builder;

import org.openqa.selenium.WebDriver;

import ui.automation.managers.FileReaderManager;

public class TestSoul {
	private static WebDriver browserInstance = null;
	private static String url = null;
	
	public static WebDriver getBrowserInstance() {
		
		url = FileReaderManager.getInstance().getConfigReader().getApplicationUrl();
		Browser b = new Browser.OpenBrowser("chrome").withUrl(url).withImplicitTimeoutInSecond(10).maximizeBrowser().build();
		browserInstance = b.getBrowserHandle();
		
		return browserInstance;
		
	}
	
	public static String getUrl() {
		return FileReaderManager.getInstance().getConfigReader().getApplicationUrl();
	}
	
	

}
