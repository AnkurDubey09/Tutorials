
package ui.automation.test;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import ui.automation.managers.FileReaderManager;
import ui.automation.selenium.design.pattern.factory.BrowserFactory;

public class TestGoogle {
	
	protected WebDriver browser;
	
	@Test
	public void testDemo() {
		browser = new BrowserFactory().getBrowser();
		browser.get(FileReaderManager.getInstance().getConfigReader().getApplicationUrl());
	}

}
